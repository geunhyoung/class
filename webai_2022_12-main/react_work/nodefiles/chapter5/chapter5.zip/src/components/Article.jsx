function Article() {
  return (
    <div className="article">
      <h1>section</h1>
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Perferendis
        quibusdam sit esse soluta aperiam in autem inventore illum ipsa
        recusandae nam optio, sint alias ducimus laboriosam aut iste asperiores.
        Possimus?
      </p>
    </div>
  );
}

export default Article;
