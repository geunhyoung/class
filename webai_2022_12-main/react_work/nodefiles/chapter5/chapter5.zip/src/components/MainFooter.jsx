import React from 'react';

function MainFooter() {
  return (
    <div id="main_footer">
      <h3>footer</h3>
      <address>대구 광역시 동구 동부로 121 경북산업직업전문학교</address>
    </div>
  );
}

export default MainFooter;
